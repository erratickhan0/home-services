<template>
    <div class="no-records-found">
        <div class="verticle-align">
            <div class="inner text-center">
                <span class="no-records-found-icon"></span>
                <p>No record found!</p>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        data(){
            return {
                none: true
            }
        }
    }

</script>

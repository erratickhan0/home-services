<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LabourLocation extends Model
{
    //
}

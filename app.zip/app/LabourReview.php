<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LabourReview extends Model
{
    protected $table='labour_reviews';
}
